import java.util.Scanner;

public class LinkedList 
{
	Node head; 
	class Node 
	{
		int data;
		Node next;
		Node(int d)
		{
			data = d;
			next = null;
		}
	}
	void getNthFromLast(int n, int b)
	{   
		if(n>b) {
			System.out.println(-1);
			System.exit(0);
		}
		int len = 0;
		Node temp = head;
	    while (temp != null) 
	    {
			temp = temp.next;
			len++;
	    }
		if (len < n)
			return;
		temp = head;
		for (int i = 1; i < len - n + 1; i++)
			temp = temp.next;
		System.out.println(n+"th node from the end is "+temp.data);
	}
	public void add(int newData)
	{
		Node newNode = new Node(newData);
		newNode.next = head;
		head = newNode;
	}
	public static void main(String[] args)
	{   Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of test case:");
	    int t = sc.nextInt();
		while(t>0) {
	    int a;
		LinkedList l = new LinkedList();
		System.out.println("Enter number of nodes in list:");
		a= sc.nextInt();
		System.out.println("Enter Elements:");
		for(int i=0;i<a;i++)
		{   int p = sc.nextInt();
		    l.add(p);
		}
		System.out.println("Enter Nth node:");
		int s = sc.nextInt();
		l.getNthFromLast(s,a);
		t--;
	}}
}