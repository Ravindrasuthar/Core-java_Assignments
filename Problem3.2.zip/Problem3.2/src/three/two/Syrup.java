package three.two;

public class Syrup implements MedicineInfo {

	@Override
    public void displayLabel() {
   	 System.out.println("Dispence in a tight,light-resistant container");
    }
}
