package three.two;

import java.util.Random;

public class TestMedicine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
MedicineInfo[] MedicineInfos = new MedicineInfo[10];
		
		Random rand = new Random();
	    
	    for (int i = 0; i < 10; i++) {
	    	int randomNum = rand.nextInt((3 - 1) + 1) + 1;
	    	
	    	if (randomNum == 1)
	    		MedicineInfos[i] = new Tablet();
	    	else if (randomNum == 2)
	    		MedicineInfos[i] = new Syrup();
	    	else if (randomNum == 3)
	    		MedicineInfos[i] = new Ointment();
	    	
	    	MedicineInfos[i].displayLabel();
	    }
	    
	    for (int i = 0; i < 10; i++) {
	    	if (MedicineInfos[i] instanceof Tablet) 
	    		System.out.println("Tablet is stored at index " + i);
	    	else if (MedicineInfos[i] instanceof Syrup) 
	    		System.out.println("Syrup is stored at index " + i);
	    	else if (MedicineInfos[i] instanceof Ointment) 
	    		System.out.println("Ointment is stored at index " + i);
	    }

	}

	}


