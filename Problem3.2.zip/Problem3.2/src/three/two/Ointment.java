package three.two;

public class Ointment implements MedicineInfo{
	
	@Override
    public void displayLabel() {
   	 System.out.println("for external use only");
    }

}
