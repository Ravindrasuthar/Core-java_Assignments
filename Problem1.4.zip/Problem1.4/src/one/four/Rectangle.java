package one.four;

public class Rectangle {
	   
	private float l;
	private float b;
	private float a;
	private float p;
	
	public Rectangle() {
		this.l = 1;
		this.b = 1;
	}

	Rectangle(float x, float y)
	{
		setL(x);
		setB(y);
	}
	
		public float getL() {
		return l;
	}

	public void setL(float l) {
		if(l>0.0 && l<20.0)
		{
			this.l =l;
		}
	}

	public float getB() {
		return b;
	}

	public void setB(float b) {
		if(b>0.0 && b<20.0)
		{
			this.b = b;
		}
	}

	public void area() {
		a=l*b;
		System.out.println("Length="+l +" Breadth="+b +" Area:"+a);
	}
	public void peri(){
		p=2*(l+b);
		System.out.println("Length="+l +" Breadth="+b +" Perimeter:"+p);
	}
}

