package one.four;

public class TestRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle rl = new Rectangle();
	       rl.area();
	       rl.peri();
	       Rectangle rl1 = new Rectangle(9,8);
	       rl1.area();
	       rl1.peri();
	       Rectangle rl2 = new Rectangle(1,6);
	       rl2.area();
	       rl2.peri();
	       Rectangle rl3 = new Rectangle(5,19);
	       rl3.area();
	       rl3.peri();
	       Rectangle rl4 = new Rectangle(6,16);
	       rl4.area();
	       rl4.peri();
	}

}
