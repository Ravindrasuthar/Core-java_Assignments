package two.three;

import java.util.Arrays;

public class Arr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0,avg,max=2147483647;
		int A[] = {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
		for(int i=0; i<=14; i++)
		{
			sum+=A[i];
		}
		A[15]=sum;
		avg = (2*sum)/A.length;
		A[16]=avg;
		for(int i=0;i<A.length-1;i++)
		{
			if(A[i]<max)
			{
				max =A[i];
			}
		}
		A[17]=max;
		for(int i=0;i<A.length;i++)
		{
			System.out.print(A[i]+" ");
		}
	}

}
