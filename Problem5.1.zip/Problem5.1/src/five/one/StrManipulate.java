package five.one;

public class StrManipulate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      String str = "Java is Simple";
      System.out.println(str.toUpperCase());
      System.out.println(str.toLowerCase());
      String[] a = str.split(" ", 3);
      for(String b: a)
      {
    	  System.out.print(b.charAt(0)+" ");
      } 
      System.out.println();
      
      String w[]=str.split("\\s");  
      String reverseWord="";  
      for(String wrd:w){  
          StringBuilder sb=new StringBuilder(wrd);  
          sb.reverse();  
          reverseWord+=sb.toString()+" ";  
      }
      System.out.println(reverseWord.trim()); 
      
      System.out.println("Total length is :"+str.replace(" ","").length());
	}

}
