package fifteen;

import java.util.Arrays;

public class Solution {

	public static int platformsNeeded(int arrival[], int departure[]) {
		Arrays.sort(arrival);
		Arrays.sort(departure);
		
		int i=0;
		int j=0;
		int count =0;
		int max = Integer.MIN_VALUE;
		
		while(i<arrival.length && j<departure.length) {
			if(arrival[i]<departure[j]) {
				count++;
				i++;
				
			}
			else {
				count--;
				j++;
			}
			
			if(count>max) {
				max = count;
			}
		}
		return max;
	}
}
