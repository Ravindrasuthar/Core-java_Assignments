package three.one;

public abstract class Instrument {
	public abstract void play();
}
