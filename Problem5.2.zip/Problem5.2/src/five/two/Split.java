package five.two;


public class Split {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      String str = "23  +      45   - (   343   /   12  )";
      String[] s = str.split("\\s+");
      for(String w:s)
      {
    	 System.out.println(w);
      }
	}

}
