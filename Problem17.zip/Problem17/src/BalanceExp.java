
import java.util.Stack;
 
class BalanceExp
{
    public static boolean isBalanced(String str)
    {  
        if (str == null || str.length() % 2 == 1) {
            return false;
        } 
        Stack<Character> s = new Stack<>(); 
        for (char c: str.toCharArray())
        {
            if (c == '(') {
                s.push(')');
            }
            else if (c == '{') {
                s.push('}');
            }
            else if (c == '[') {
                s.push(']');
            }
            else if (s.isEmpty() || s.pop() != c) {
                return false;
            }
        }
        return s.empty();
    }
 
    public static void main(String[] args)
    {
        String str = "�[(])}";
        if (isBalanced(str)) {
            System.out.println("Balanced");
        }
        else {
            System.out.println("Not Balanced");
        }
    }
}

