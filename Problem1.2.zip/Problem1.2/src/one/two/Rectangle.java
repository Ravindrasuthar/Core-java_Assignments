package one.two;

public class Rectangle {
	   
	private float l;
	private float b;
	private float a;
	
	public Rectangle() {
		this.l = 0;
		this.b = 0;
	}

	Rectangle(float l, float b)
	{
		this.l = l;
		this.b = b;
	}
	
	public void area() {
		a=l*b;
		System.out.println("Length="+l +" Breadth="+b +" Area:"+a);
	}
}

