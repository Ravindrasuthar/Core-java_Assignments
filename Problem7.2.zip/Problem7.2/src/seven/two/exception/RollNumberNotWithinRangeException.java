package seven.two.exception;

public class RollNumberNotWithinRangeException extends Exception{
    
	public RollNumberNotWithinRangeException(String mssg) {
		
		super(mssg);
	}
}
