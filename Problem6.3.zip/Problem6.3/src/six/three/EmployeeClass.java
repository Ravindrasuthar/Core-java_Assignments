package six.three;

public class EmployeeClass 
{
	private int empno;
	   private String ename;
	   private String address;

	   EmployeeClass(int empno, String ename, String address){
	      this.empno = empno;
	      this.ename = ename;
	      this.address = address;
	   }

	   public int getEmpno(){
	      return empno;
	   }
	   public String getAddress(){
	      return address;
	   }
	   public String getEname(){
	      return ename;
	   }

	   public String toString(){
	      return empno+" "+ename+" "+address;
	   }

}