package five.three;

public class Replace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       String str = "MPHASIS";
       int a = str.length();
       System.out.println(str);
       for(int i=0;i<a;i++)
       {
    	   str = (str.substring(1, a)+str.charAt(0));
           System.out.println(str);
       }
      
       
	}

}
