package seven.two.exception;

public class AgeNotWithinRangeException extends Exception{
	
	public AgeNotWithinRangeException(String mssg) {
		
		super(mssg);
	}

}