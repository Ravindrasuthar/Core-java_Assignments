package two.one;

import java.util.Scanner;

public class Palindrome
{
	public static void main(String args[])
    {
        String a, b = "";
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the string you want to check:");
        a = sc.nextLine();
        int n = a.length();
        System.out.println("Length of String: "+ n);
        System.out.println("String in uppercase:"+a.toUpperCase());
        for(int i = n - 1; i >= 0; i--)
        {
            b = b + a.charAt(i);
        }
        if(a.equalsIgnoreCase(b))
        {
            System.out.println("The string is palindrome.");
        }
        else
        {
            System.out.println("The string is not palindrome.");
        }
    }
}
