import java.util.Scanner;
import java.util.Vector;

public class Mininmum {
   
	static int num[] = {1,2,5,10,20,50,100,500,2000};
	static int n = num.length;
	static void minimum(int a)
	{
		Vector<Integer> v = new Vector<>();
		
		for(int i = n-1;i>=0;i--)
		{
			while(a>=num[i])
			{
				a-=num[i];
				v.add(num[i]);
			}
		}
		
		for(int i=0; i<v.size();i++)
		{
			System.out.print(" "+ v.elementAt(i));
		}
	}
	public static void main(String[] args)
	{   
		Scanner sc = new Scanner(System.in);
		int p;
		System.out.println("Enter number:");
		p = sc.nextInt();
		System.out.println("minimal number of changes for "+p+":");
		minimum(p);
	}
}
