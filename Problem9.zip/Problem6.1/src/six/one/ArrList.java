package six.one;

import java.util.ArrayList;

public class ArrList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      ArrayList<String> str = new ArrayList<String>();
      str.add("Raj");
      str.add("Raman");
      str.add("Rajneesh");
      str.add("Ravindra");
      str.add("Kunal");
      System.out.println(str);
      //find for name Raman if it exist it return true else it return false
      System.out.println(str.contains("Raman"));
	}

}
