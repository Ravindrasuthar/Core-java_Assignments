package six.four;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HashmapExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x;
      Scanner sc = new Scanner(System.in);
	  Map<String,String> Phonebook = new HashMap<String,String>();
	  
	  while(true) {
	  System.out.println("1. add name and phone number");
	  System.out.println("2. Search for phone number using name");
	  System.out.println("3.exit");
	  x= sc.nextInt();
	  switch(x) {
	  
	  case 1 :
      System.out.println("Enter name and Phone numbers:");
      for(int i=0; i<3; i++)
      {
      Phonebook.put(sc.next(), sc.next());
      }
      System.out.println("Phonebook is:");
      System.out.println(Phonebook);
      break;
      
	  case 2:
      System.out.println("Enter name to search Phone number:");
      String name = sc.next();
      if(Phonebook.containsKey(name)) {
    	  System.out.println(Phonebook.get(name));
      }
      else {
    	  System.out.println("Name not exist");
      }
      break;
	  case 3: System.exit(0);
	}
	
	}}
	}

