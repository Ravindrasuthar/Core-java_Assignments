package two.two;

import java.util.Scanner;

public class Fibo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc = new Scanner(System.in);
      int a,b,c;
      System.out.println("Enter two numbers:");
      a= sc.nextInt();
      b= sc.nextInt();
      System.out.print(a+" "+b+" ");
      for(int i=0;i<13;i++)
      {
    	  c=a+b;
    	  System.out.print(c+" ");
    	  a=b;
    	  b=c;
      }
	}
}
