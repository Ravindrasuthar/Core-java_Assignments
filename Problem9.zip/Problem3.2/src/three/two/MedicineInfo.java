package three.two;

public interface MedicineInfo {
     
	public abstract void displayLabel();
}
