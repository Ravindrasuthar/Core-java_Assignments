package fifteen;

public class Main {

	public static void main(String[] args) {
		
		int arrival[] =  { 900, 940, 950, 1100, 1500, 1800};
		int departure[] = {910, 1200, 1120, 1130, 1900, 2000 };
		System.out.println(fifteen.Solution.platformsNeeded(arrival, departure));	
	}
}
