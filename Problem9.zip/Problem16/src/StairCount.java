import java.util.Scanner;

public class StairCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc = new Scanner(System.in);
      int n,a=1,b=2,c=0;
      System.out.println("Enter number of stairs:");
      n = sc.nextInt();
      if(n>=1 && n<=45) {
      if(n==1)
      {
    	  System.out.println(1);
      }else
    	  if(n==2) {
    		  System.out.println(2);
    	  }else {
      for(int i=2;i<n;i++)
      {
    	  c=a+b;
    	  a=b;
    	  b=c;
      }
      System.out.println(b);
	}
   }else
   {
	   System.out.println("Enter number in range of 1 to 45");
   }
  }
}