package one.two;

public class TestReactangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Rectangle rl = new Rectangle();
       rl.area();
       Rectangle rl1 = new Rectangle(9,8);
       rl1.area();
       Rectangle rl2 = new Rectangle(1,6);
       rl2.area();
       Rectangle rl3 = new Rectangle(5,10);
       rl3.area();
       Rectangle rl4 = new Rectangle(6,16);
       rl4.area();
	}

}
